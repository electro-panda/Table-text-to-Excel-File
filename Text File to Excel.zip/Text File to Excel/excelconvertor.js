
const Subbtn=document.querySelector("#Submit_btn");
const downloadbtn=document.querySelector("#btnf");
Subbtn.onclick=generatingTable;
downloadbtn.onclick=DownloadExcelFile;

function generatingTable(){
    const rows=parseInt(document.querySelector("#rowsinput").value);
    const columns=parseInt(document.querySelector("#Columninput").value);
    if(rows<=0 || columns<=0){
    alert("You can't enter 0 or less then 0");
    return;
    }
    let tableContainer = document.getElementById("third_Div");
    tableContainer.innerHTML = "";
    const table1=document.createElement("table");
    table1.className="table table-success table-striped";
    table1.id="Tid";
    const tbody1=document.createElement("tbody");
    for(let i=0;i<rows;i++){
        const tr1=document.createElement("tr");
            for(let j=0;j<columns;j++){
                const td1=document.createElement("td");
                const inp1=document.createElement("input")
                inp1.placeholder ="Enter the value";
                inp1.type="text";
                td1.appendChild(inp1);
                tr1.appendChild(td1);
            }
            tbody1.appendChild(tr1);
            table1.appendChild(tbody1);
    }
    tableContainer.appendChild(table1);
    downloadbtn.style.display="block";
}

function DownloadExcelFile(){
            let table = document.getElementById("Tid");
            let rows = table.getElementsByTagName("tr");
            let data = [];
            if (!table) {
                alert("No table found! Please generate a table first.");
                return;
            }
            for (let i = 0; i < rows.length; i++) 
            {
                    let row = [];
                    let cells = rows[i].getElementsByTagName("td");

                    for (let j = 0; j < cells.length; j++) {
                        let input = cells[j].getElementsByTagName("input")[0];
                        row.push(input ? input.value : cells[j].innerText);
                }

                data.push(row);
            }

            let sheet = XLSX.utils.aoa_to_sheet(data);
            let book = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(book, sheet, "Sheet1");
            XLSX.writeFile(book, "table_data.xlsx");
}
